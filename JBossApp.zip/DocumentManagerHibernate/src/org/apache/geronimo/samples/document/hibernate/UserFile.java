package org.apache.geronimo.samples.document.hibernate;

import java.sql.Timestamp;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class UserFile {

	int id;
	String userid;
	String filename;
	Timestamp timestamp;
	
	public UserFile(){ 
		
	}
	
	public UserFile(String userid, String filename, Timestamp timestamp){
		
		this.userid = userid;
		this.filename = filename;
		this.timestamp = timestamp;
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	
	
}
