package org.apache.geronimo.samples.document.ejb;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.SessionContext;

import org.apache.geronimo.samples.document.dao.DocumentManagerDAO;
import org.apache.geronimo.samples.document.hibernate.UserFile;


/**
 * @ejb.bean name="DocumentManager"	
 *           description="DocumentManager"
 *           display-name="DocumentManager"
 *           jndi-name="ejb/DocumentManager"
 *           type="Stateless" 
 *           transaction-type="Container"
 *           view-type="remote"
 *           
 * @ejb.interface generate="remote" remote-class="org.apache.geronimo.samples.document.ejb.DocumentManager"
 * @ejb.home generate="remote" remote-class=""-class="org.apache.geronimo.samples.document.ejb.DocumentManagerHome"
 * 
 */
public class DocumentManagerBean implements javax.ejb.SessionBean {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5910882211249828856L;

	/**
	 * @ejb.interface-method view-type="remote"
	 * @ejb.permission role-name = "uploader"
	 * @return result message
	 */
		
	public String upload(String userId, String filename) {
		addUserFile(userId, filename);
		return "File successfully uploaded";
	}

	 public List<UserFile> getFilesByUserid(String userid) {
		 List<UserFile> list = null;
		 try {
			DocumentManagerDAO dmDao = new DocumentManagerDAO();
			list = dmDao.getUserFilesByUserid(userid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   return list;
	   }
	 private void addUserFile(String userId, String filename) {
		 DocumentManagerDAO dmDao;
		 
		try {
			dmDao = new DocumentManagerDAO();
			dmDao.addUserFile(userId, filename);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	/**
	 * @ejb.permission unchecked="true"
	 * @ejb.create-method view-type="remote"
	 * @generated
	 */
	public void ejbCreate() {
	}

	public void ejbActivate() throws EJBException, RemoteException {
	}

	public void ejbPassivate() throws EJBException, RemoteException {
	}

	public void ejbRemove() throws EJBException, RemoteException {
	}

	public void setSessionContext(SessionContext arg0) throws EJBException, RemoteException {
	}
}
