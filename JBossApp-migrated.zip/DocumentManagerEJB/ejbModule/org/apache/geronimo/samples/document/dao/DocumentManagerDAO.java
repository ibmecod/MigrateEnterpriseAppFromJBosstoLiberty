package org.apache.geronimo.samples.document.dao;

import java.sql.Timestamp;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.Transactional;

import org.apache.geronimo.samples.document.hibernate.UserFile;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DocumentManagerDAO {

	SessionFactory factory  = null;
	Session session = null;
	static int id = 1000;
	
	public DocumentManagerDAO() throws Exception {

		try {
			InitialContext ctx = new InitialContext();
			factory  = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();

		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public List<UserFile> getUserFilesByUserid(String userid) throws Exception {

//		session = factory.getCurrentSession();
		session = factory.openSession();
		
		Query q = session.createQuery("from UserFile f where f.userid=:userid");
		q.setString("userid", userid);
		return q.list();

	}


	public List getUserFiles() throws Exception {

//		session = factory.getCurrentSession();
		session = factory.openSession();
		
		Query q = session.createQuery("from UserFile");
		List files = q.list();
		return files;

	}

	public boolean addUserFile(String userId, String filename)
			throws Exception {

		if(userId == null || userId.isEmpty() || filename == null || filename.isEmpty()){
			return false;
		}
		
//		session = factory.getCurrentSession();
		session = factory.openSession();
		
		long curTime = System.currentTimeMillis();
		
		Timestamp timestamp = new Timestamp(curTime);
		
		UserFile userfile = new UserFile(userId, filename, timestamp);
		
		Transaction tx;
		tx = session.beginTransaction();
		session.save(userfile);
		tx.commit();
		return true;

	}

	public void remove() throws Exception {

	}

}
