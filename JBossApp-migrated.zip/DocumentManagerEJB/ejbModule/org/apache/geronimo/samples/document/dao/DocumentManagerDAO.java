package org.apache.geronimo.samples.document.dao;

import java.sql.Timestamp;
import java.util.List;

import org.apache.geronimo.samples.document.hibernate.UserFile;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DocumentManagerDAO {

	SessionFactory factory  = null;
	Session session = null;
	static int id = 1000;
	
	public DocumentManagerDAO() throws Exception {

		factory  = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();

	}

	@SuppressWarnings("unchecked")
	public List<UserFile> getUserFilesByUserid(String userid) throws Exception {

		// CMT
//		session = factory.getCurrentSession();
		// BMT
		session = factory.openSession();
		
		Query q = session.createQuery("from UserFile f where f.userid=:userid");
		q.setString("userid", userid);
		return q.list();

	}


	@SuppressWarnings("unchecked")
	public List<UserFile> getUserFiles() throws Exception {

		// CMT
//		session = factory.getCurrentSession();
		// BMT
		session = factory.openSession();

		Query q = session.createQuery("from UserFile");
		return q.list();

	}

	public boolean addUserFile(String userId, String filename)
			throws Exception {

		if(userId == null || userId.isEmpty() || filename == null || filename.isEmpty()){
			return false;
		}
		
		// CMT
//		session = factory.getCurrentSession();
		// BMT
		session = factory.openSession();
		
		long curTime = System.currentTimeMillis();
		
		Timestamp timestamp = new Timestamp(curTime);
		
		UserFile userfile = new UserFile(userId, filename, timestamp);

		// CMT
//		session.save(userfile);
		// BMT
		Transaction tx;
		tx = session.beginTransaction();
		session.save(userfile);
		tx.commit();
		
		return true;

	}

	public void remove() throws Exception {

	}

}
