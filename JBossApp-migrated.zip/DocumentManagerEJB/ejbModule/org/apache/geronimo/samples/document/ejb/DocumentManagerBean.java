package org.apache.geronimo.samples.document.ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.geronimo.samples.document.dao.DocumentManagerDAO;
import org.apache.geronimo.samples.document.hibernate.UserFile;


/**
 * @ejb.bean name="DocumentManager"	
 *           description="DocumentManager"
 *           display-name="DocumentManager"
 *           jndi-name="ejb/DocumentManager"
 *           type="Stateless" 
 *           transaction-type="Bean"
 *           view-type="remote"
 *           
 * @ejb.interface generate="remote" remote-class="org.apache.geronimo.samples.document.ejb.DocumentManager"
 * @ejb.home generate="remote" remote-class=""-class="org.apache.geronimo.samples.document.ejb.DocumentManagerHome"
 * 
 */
@Stateless
@TransactionManagement(value=TransactionManagementType.BEAN)
public class DocumentManagerBean {
	
	public String upload(String userId, String filename) {
		addUserFile(userId, filename);
		return "File successfully uploaded";
	}

	 public List<UserFile> getFilesByUserid(String userid) {
		 List<UserFile> list = null;
		 try {
			DocumentManagerDAO dmDao = new DocumentManagerDAO();
			list = dmDao.getUserFilesByUserid(userid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   return list;
	   }
	 
	 private void addUserFile(String userId, String filename) {
		 DocumentManagerDAO dmDao;
		 
		try {
			dmDao = new DocumentManagerDAO();
			dmDao.addUserFile(userId, filename);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
}
