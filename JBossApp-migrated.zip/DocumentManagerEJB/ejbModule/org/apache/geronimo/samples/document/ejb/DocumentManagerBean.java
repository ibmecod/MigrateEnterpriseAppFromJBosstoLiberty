package org.apache.geronimo.samples.document.ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.geronimo.samples.document.dao.DocumentManagerDAO;
import org.apache.geronimo.samples.document.hibernate.UserFile;

@Stateless
// BMT
@TransactionManagement(value=TransactionManagementType.BEAN)
public class DocumentManagerBean {
	
	public String upload(String userId, String filename) {
		addUserFile(userId, filename);
		return "File successfully uploaded";
	}

	 public List<UserFile> getFilesByUserid(String userid) {
		 List<UserFile> list = null;
		 try {
			DocumentManagerDAO dmDao = new DocumentManagerDAO();
			list = dmDao.getUserFilesByUserid(userid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   return list;
	   }
	 private void addUserFile(String userId, String filename) {
		 DocumentManagerDAO dmDao;
		 
		try {
			dmDao = new DocumentManagerDAO();
			dmDao.addUserFile(userId, filename);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
}
