package org.apache.geronimo.samples.document.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.geronimo.samples.document.ejb.DocumentManagerBean;
import org.apache.geronimo.samples.document.hibernate.UserFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@WebServlet({"/RetrieveServlet"})
public class RetrieveServlet extends HttpServlet
{
	Logger logger = LoggerFactory.getLogger(RetrieveServlet.class);
	
	private static final long serialVersionUID = -2773446199481416101L;
	@EJB
	private DocumentManagerBean docManager;
	
	
//	public void destroy() {
//		docManagerHome = null;
//		super.destroy();
//	}
//
//	public void init() throws ServletException {
//		try {
//			Context context = new InitialContext();
//			docManagerHome = (DocumentManagerHome)context.lookup(DocumentManagerHome.JNDI_NAME);
//		} catch (Throwable e) {
//			throw new ServletException(e);
//		}
//	}
//
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
//		DocumentManager docManager = getDocumentManager();
		PrintWriter out = res.getWriter();
		
		logger.info("req = " + req);
		logger.info("req.getUserPrincipal() = " + req.getUserPrincipal());
		logger.info("req.getUserPrincipal().getName() = " + req.getUserPrincipal().getName());
		
		String userid = req.getUserPrincipal().getName();
		List<UserFile> docs = docManager.getFilesByUserid(userid);
		if (docs != null) {
			for (int i = 0; i < docs.size(); ++i) {
				out.append("<TR>");
				out.append("<TD>" + i + "</TD>");
				out.append("<TD>" + docs.get(i).getFilename() + "</TD>");
				out.append("<TD>" + docs.get(i).getTimestamp().toString() + "</TD>");
				out.append("</TR>");
			}
		}
		out.append("</TBODY>");
		out.append("</TABLE>");

		req.setAttribute("Doclist", out);
	}
	

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
	
	
//	private DocumentManager getDocumentManager() throws ServletException, IOException {
//		try {
//			return docManagerHome.create();
//		} catch (CreateException e) {
//			throw new ServletException(e);
//		} 
//	}
//
}
