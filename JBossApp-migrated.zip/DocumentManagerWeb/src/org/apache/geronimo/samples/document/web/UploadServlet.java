package org.apache.geronimo.samples.document.web;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.geronimo.samples.document.ejb.DocumentManagerBean;

@WebServlet({"/UploadServlet"})
public class UploadServlet extends HttpServlet{

	private static final long serialVersionUID = -2773446199481416101L;
	@EJB
	private DocumentManagerBean docManager;
	
	
//	public void destroy() {
//		docManagerHome = null;
//		super.destroy();
//	}
//
//	public void init() throws ServletException {
//		try {
//			Context context = new InitialContext();
//			docManagerHome = (DocumentManagerHome)context.lookup(DocumentManagerHome.JNDI_NAME);
//		} catch (Throwable e) {
//			throw new ServletException(e);
//		}
//	}
//
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
//		DocumentManager docManager = getDocumentManager();
		String filename = req.getParameter("file");
		String userID = req.getUserPrincipal().getName();
		req.setAttribute("result", docManager.upload(userID, filename));
		req.getRequestDispatcher("jsp/main.jsp").forward(req, res);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
	
	
//	private DocumentManager getDocumentManager() throws ServletException, IOException {
//		try {
//			return docManagerHome.create();
//		} catch (CreateException e) {
//			throw new ServletException(e);
//		} 
//	}
//
}
